# AppShell
PLEASE DOWNLOAD THIS FIRST.

The basic app shell for SPA - partial view approach (HTML, CSS, Images and core JS only)

Upload to your OSWS - create a directory structure of your choice: suggest MAD_17>PoS
